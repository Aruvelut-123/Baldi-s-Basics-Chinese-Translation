Baldi's Basics Plus汉化版介绍:
Baldi's Basics Plus中文名 Baldi的基础教育+
是由MEMZSystem32&Baymaxawa汉化制作的，游戏制作人是Mystman12

继Baldi's Basics Classic Remsaetered汉化版以来的第二个Baldi's Basics汉化作品

版本:1.9.1 Beta 2
更新内容: 
1.修复0.7.1兼容性问题


使用方法:
将压缩包里的文件扔进你的Baldi's Bascis Plus 游戏文件即可
拒绝盗版从我做起

MEMZSystem32 的 QQ：2324271769
有事联系